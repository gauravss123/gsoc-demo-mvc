Ext.define('test.model.city', {
    extend: 'Ext.data.Model',

    config: {
        fields: ['Serv']
    }
});