Ext.define('test.model.state', {
    extend: 'Ext.data.Model',

    config: {
        fields: ['Serv']
    }
});