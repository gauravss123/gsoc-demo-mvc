Ext.define('test.model.list1model', {
    extend: 'Ext.data.Model',

    config: {
        fields: ['Pharmacy', 'Ambulance', 'Government', 'State', 'City', 'lat', 'long', 'firstName', 'lastName']
    }
});