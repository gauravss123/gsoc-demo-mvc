Ext.define('test.model.addoc', {
    extend: 'Ext.data.Model',

    config: {
        fields: ['Serv']
    }
});